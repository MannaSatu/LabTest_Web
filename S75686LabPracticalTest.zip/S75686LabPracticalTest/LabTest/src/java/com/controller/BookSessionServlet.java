package com.controller;

import com.bean.SessionBean;
import com.dao.SessionDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "BookSessionServlet", urlPatterns = {"/BookSessionServlet"})
public class BookSessionServlet extends HttpServlet {

    private SessionDAO sessionDAO = new SessionDAO();
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
            String student_name = request.getParameter("student_name");
            String branch_location = request.getParameter("branch_location");
            String lesson_type = request.getParameter("lesson_type");
            Session newSession = new Session(student_name, branch_location, lesson_type, status="Booked");
            SessionDAO.bookSession(newSession);
            response.sendRedirect("ScheduleServlet");
    }
}
