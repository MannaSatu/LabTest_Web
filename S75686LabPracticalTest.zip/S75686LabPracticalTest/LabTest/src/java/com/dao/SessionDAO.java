package com.dao;

import com.bean.SessionBean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SessionDAO {
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/drivesmart_db","root", "");
    }
public boolean bookSession(SessionBean session) {
    try (Connection conn = getConnection()) {
        String sql = "INSERT INTO trainingsessions (student_name,branch_location,lesson_type) VALUES (?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, student.getstudent_name());
        pstmt.setString(2, student.getbranch_location());
        pstmt.setString(3, student.getlesson_type());
        return pstmt.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
public  List < Employee > getAllSessions() {
//return list sessionbean
List < SessionBean > sessions = new ArrayList < > ();
try (Connection conn = getConnection();
        String sql="SELECT*FROM trainingsessions ORDER BY branch_location ASC";
        PreparedStatement pstmt = conn.prepareStatement(sql);){
        System.out.println(pstmt);
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
            int session_id = rs.getInt("session_id");
            String student_name = rs.getString("student_name");
            String branh_location = rs.getString("branch_location");
            String lesson_type = rs.getString("lesson_type");
            trainingsessions.add(new session(session_id,student_name,branch_location,lesson_type));
        }
        }catch (SQLExcetion e){
                printSQLException(e);
                }
        return trainingsessions;
}
}

