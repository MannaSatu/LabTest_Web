package com.bean;

import java.io.Serializable;

public class SessionBean implements java.io.Serializable {
private String student_name;
private String branch_location;
private String lesson_type;
private String status;

//empty constructor
public SessionBean() {}

//getset for student name
public String getstudent_name() { return student_name; }
public void setstudent_name(String student_name) { this.student_name = student_name; }

//getset for branch location
public String getbranch_location() { return branch_location; }
public void setbranch_location(String branch_location) { this.branch_location = branch_location; }

//getset for lesson type
public String getlesson_type() { return lesson_type; }
public void setlesson_type(String lesson_type) { this.lesson_type = lesson_type; }

//getset for status
public String getstatus() { return status; }
public void setstatus(String status) { this.status = status; }
}