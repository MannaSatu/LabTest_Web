<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 4:07:47 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Book Session</title>
    </head>
    <body>
        <header>Drive Smart Academy</header>
        <h2>Register New Session</h2>
        <form action="UserServlet" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="register">
            Student Name: <input type="text" name="student_name" required><br><br>
            Branch Location: <input type="text" name="branch_location" required><br><br>
            Lesson Type: <input type="password" name="password" required><br><br>
            <br>
            <br>
            <input type="submit" action="BookSessionServlet">
</form>
    </body>
</html>
