<%-- 
    Document   : index
    Created on : 16 Jun 2026, 4:36:10 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <div class ="container">
            <div class="card">
                <a href="book_session.jsp" class="btn">Book Session</a>
                <a href="ScheduleServlet.jsp" class="btn">Schedule</a>
            </div>
        </div>
    </body>
</html>
